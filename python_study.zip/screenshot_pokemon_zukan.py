# Seleniumを使ってPythonでスクリーンショットを取得する https://self-development.info/selenium%e3%82%92%e4%bd%bf%e3%81%a3%e3%81%a6python%e3%81%a7%e3%82%b9%e3%82%af%e3%83%aa%e3%83%bc%e3%83%b3%e3%82%b7%e3%83%a7%e3%83%83%e3%83%88%e3%82%92%e5%8f%96%e5%be%97%e3%81%99%e3%82%8b/
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
import time

URL = "https://ja.wikipedia.org/wiki/%E5%85%A8%E5%9B%BD%E3%83%9D%E3%82%B1%E3%83%A2%E3%83%B3%E5%9B%B3%E9%91%91%E9%A0%86%E3%81%AE%E3%83%9D%E3%82%B1%E3%83%A2%E3%83%B3%E4%B8%80%E8%A6%A7"
# XPathの調べ方 https://prtn-life.com/blog/selenium-xpath
XPATH_NO	= '//*[@id="mw-content-text"]/div[1]/table[1]/tbody/tr[1]/td[1]/table/tbody/tr[2]/td[1]'
XPATH_LINK	= '//*[@id="mw-content-text"]/div[1]/table[1]/tbody/tr[1]/td[1]/table/tbody/tr[2]/td[2]/a'
# XPATH_NO	= '//*[@id="mw-content-text"]/div[1]/table[11]/tbody/tr[3]/td[3]/table/tbody/tr[6]/td[1]'
# XPATH_LINK	= '//*[@id="mw-content-text"]/div[1]/table[11]/tbody/tr[3]/td[3]/table/tbody/tr[6]/td[2]/a'

options = Options()
# スクロールバーを非表示にする
options.add_argument('--hide-scrollbars')
# シークレットモードでChromeを起動する
options.add_argument('--incognito')
# ブラウザを表示しない
options.add_argument('--headless')
 
# driver = webdriver.Chrome(CHROMEDRIVER, options=options)
# webdriver.Chrome()のエラー https://qiita.com/nonnta_/items/0ceae7889dd50908fef3
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
 
# ウィンドウサイズ＝画像サイズ
driver.set_window_size(1920, 1080)
# 【STEP1】Webサイトを開く https://prtn-life.com/blog/selenium-link#toc6
driver.get(URL)
# 【STEP2】ナンバーとリンクを含む要素を取得する https://prtn-life.com/blog/selenium-link#toc7
# 【STEP3】テキスト部分とリンク部分のみ抽出 https://prtn-life.com/blog/selenium-link#toc8
num = driver.find_element(By.XPATH, XPATH_NO).text
url = driver.find_element(By.XPATH, XPATH_LINK).get_attribute('href')
# 抽出したリンクを開いてスクリーンショットを取得
driver.get(url)
driver.save_screenshot(f'./templateImg/pokemon2/result_{num}.png')
 
driver.quit()
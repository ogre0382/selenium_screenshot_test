# Seleniumを使ってPythonでスクリーンショットを取得する https://self-development.info/selenium%e3%82%92%e4%bd%bf%e3%81%a3%e3%81%a6python%e3%81%a7%e3%82%b9%e3%82%af%e3%83%aa%e3%83%bc%e3%83%b3%e3%82%b7%e3%83%a7%e3%83%83%e3%83%88%e3%82%92%e5%8f%96%e5%be%97%e3%81%99%e3%82%8b/
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
import time

# CHROMEDRIVER = "chromedriver.exeのパス"
# URL = "https://www.amazon.co.jp/"
URL = "https://www.yahoo.co.jp/"

options = Options()
# スクロールバーを非表示にする
options.add_argument('--hide-scrollbars')
# シークレットモードでChromeを起動する
options.add_argument('--incognito')
# ブラウザを表示しない
options.add_argument('--headless')
 
# driver = webdriver.Chrome(CHROMEDRIVER, options=options)
# webdriver.Chrome()のエラー https://qiita.com/nonnta_/items/0ceae7889dd50908fef3
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
 
# ウィンドウサイズ＝画像サイズ
driver.set_window_size(1920, 1080)
# 【STEP1】Webサイトを開く https://prtn-life.com/blog/selenium-link#toc6
driver.get(URL)
time.sleep(3)
# 【STEP2】リンクを含む要素を取得する https://prtn-life.com/blog/selenium-link#toc7
elem = driver.find_element(By.XPATH, '//*[@id="ToolList"]/ul/li[1]/div/a')
# 【STEP3】リンク部分のみ抽出 https://prtn-life.com/blog/selenium-link#toc8
url = elem.get_attribute('href')
# 抽出したリンクを開いてスクリーンショットを取得
driver.get(url)
driver.save_screenshot('result.png')
 
driver.quit()